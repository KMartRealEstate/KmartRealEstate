# KMartRealEstate

A personal condo-watch website for downtown Toronto: the latest 1-bed listings with filtering, sorting, side-by-side comparison (up to 3 homes), and a mortgage payment calculator.

This is a single static file — `index.html` has everything baked in (styles, scripts, listing data). No build step, no dependencies.

## Publish it on GitHub Pages (no coding needed)

1. Go to [github.com/new](https://github.com/new) and create a new repository named `kmartrealestate` (public or private — see privacy note below).
2. On the new repo page, click **"uploading an existing file"** and drag in `index.html` from this package, then **Commit changes**.
3. Go to **Settings → Pages**. Under *Build and deployment*, set **Source** to **Deploy from a branch**, branch **main**, folder **/ (root)**, then **Save**.
4. After a minute or two your site is live at `https://<your-username>.github.io/kmartrealestate/`.

### Prefer the command line?

```bash
git clone https://github.com/<your-username>/kmartrealestate.git
cd kmartrealestate
cp /path/to/index.html .
git add index.html
git commit -m "Publish KMartRealEstate site"
git push
```

Then enable Pages in Settings as in step 3 above.

## Updating listings

The listing data is baked directly into `index.html` (each home is a card in the page). To refresh the listings:

- Ask Muse to update the KMartRealEstate site (e.g. "refresh the listings"), then re-export and replace `index.html` in the repo — one commit and the live site updates. GitHub Pages redeploys automatically on every push to `main`.

## Privacy note

GitHub Pages sites on the **free plan are public** — anyone with the URL can open the site. If you want the site to stay private:

- Keep the repository **private** and skip Pages (the repo is just a backup), or
- Use a **GitHub Pro** account, which allows Pages on private repos, or
- Keep the private link-only version hosted by Muse instead.

Note: the live data feed idea (auto-updating market trends) isn't possible yet — there's no public HouseSigma/market API — but hosting the site in a repo makes future automation (e.g. a scheduled update workflow) possible.
